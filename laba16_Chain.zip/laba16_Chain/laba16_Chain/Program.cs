﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laba16_Chain
{
    class Program
    {
        static void Main(string[] args)
        {
            Matrix mt = new Matrix();
            //  mt.SubstractTheSmallerElement();
            //   mt.SortLines();
           // Console.WriteLine("Исходная матрица");
           // mt.Output();
            Console.WriteLine();
            mt.InsertDublicate();
        }
    }
}
